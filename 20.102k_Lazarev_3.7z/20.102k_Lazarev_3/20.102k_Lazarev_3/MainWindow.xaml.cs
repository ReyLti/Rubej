﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using _20._102k_Lazarev_3.Entity;

namespace _20._102k_Lazarev_3
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {

            EntitiesRebej entities = new Entity.EntitiesRebej(); //Создаем модел базы данных
 
            var Baza = entities.Discipline.Where(x=>x.IdDiscipline==2).OrderBy(x=>x.Title); //создаем объект класса Discipline и осуществляем поиск по id

            if (entities.Discipline.Find(2) == null) MessageBox.Show("Записей не найдено");//если результатов не надено, то выводится сообшение
            if (Baza == null) MessageBox.Show("Не было найдено записей");
            LoadData.ItemsSource = Baza.ToList();           
        }
    }
}
